package com.arnoldas.mathteacher;

class StudentDTO
{
    public int id;
    public String name;
    int additionLevel;
    int subtractionLevel;
    int multiplicationLevel;
    int divisionLevel;
    int testTime;
}
